
export const ROAD_DATA = [
    { id: 'autovia', nombre: 'Autovía / Autopista', ejemplo: 'A-3', fondo: '#003399', texto: '#FFFFFF' },
    { id: 'nacional', nombre: 'Carretera Nacional', ejemplo: 'N-340', fondo: '#C10000', texto: '#FFFFFF' },
    { id: 'europea', nombre: 'Itinerario Europeo', ejemplo: 'E-90', fondo: '#007A33', texto: '#FFFFFF' },
    { id: 'autonomica-1', nombre: 'Autonómica 1º Nivel', ejemplo: 'A-316', fondo: '#FF6600', texto: '#000000' }
];

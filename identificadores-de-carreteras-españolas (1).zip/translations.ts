
// Este archivo ha sido reemplazado por el sistema de traducciones modulares:
// - /translations/common.ts
// - /translations/roadIds.ts
// - /translations/dataCenter.ts
export {};
